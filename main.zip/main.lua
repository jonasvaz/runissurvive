
local tilesetImage
local tileQuads = {}
local tileSize = 32
local gravity = 600

local mapa_config = {
  mapaSize_x =3872,
  mapaSize_y = 608,
  mapaDisplay_x = 121,
  mapaDisplay_y = 19
}

local camera = {
  pos_x = 1,
  pos_y = 1,
  speed = 200
}

local player = {
  image = love.graphics.newImage("mario.png"),
  pos_x = ((mapa_config.mapaDisplay_x / 2) + 170),
  pos_y = 3,
  jump = false,
  jumpForce = 500,
  jumpTime = 0
}

local mapa = {}

function LoadMap (filename) -- Le o conteúdo do arquivo para a matriz
local file = io.open(filename)
local i = 1
for line in file:lines() do
  mapa[i] = {}
for j=1, #line, 1 do
  mapa[i][j] = line:sub(j,j)
end
i = i + 1
end
file:close()
end

function love.load()
LoadMap("Mapa.txt")
lava = love.graphics.newImage("lava.png")
stone = love.graphics.newImage ("stone.png")
lavas  = love.graphics.newImage ("lava2.png")
end

function love.draw()
  
  offset_x = math.floor(camera.pos_x)  
  first_tile_x = math.floor(camera.pos_x)    
    
for i=1, mapa_config.mapaDisplay_y, 1 do
for j=1, mapa_config.mapaDisplay_x, 1 do
  
if (mapa[i][j] == "P") then
 love.graphics.draw (stone,((j-1)* tileSize) - offset_x ,((i-1)* tileSize))
  elseif
(mapa[i][j] == "A") then
love.graphics.draw (lava,((j-1)* tileSize) - offset_x ,((i-1)* tileSize))
  elseif
(mapa [i][j] == "G") then
love.graphics.draw (lavas,((j-1)* tileSize) - offset_x ,((i-1)* tileSize))
  end
end

  love.graphics.draw(player.image, player.pos_x + 80, player.pos_y+5, 0, 0.1, 0.1)
 end

function love.update (dt) 
  
  player_tile_x = math.floor((camera.pos_x + player.pos_x + (tileSize / 2)) / tileSize)
  player_tile_xr = math.floor((camera.pos_x + player.pos_x + tileSize) / tileSize)
  player_tile_xl = math.floor((camera.pos_x + player.pos_x) / tileSize)
  player_tile_y = math.floor((player.pos_y) / tileSize)
  player_tile_yr = math.floor((player.pos_y + (tileSize / 1.5)) / tileSize)
  
  
  if love.keyboard.isDown("right") and (mapa[player_tile_yr + 2][player_tile_xr + 1] == "X") then
    camera.pos_x = camera.pos_x + (camera.speed * dt)
  end
 
 
  if love.keyboard.isDown("left") and (mapa[player_tile_yr + 2][player_tile_xl + 1] == "X") then
    camera.pos_x = camera.pos_x - (camera.speed * dt)
  end
  
  
  if love.keyboard.isDown("up") and player.jump == false then
    if player_tile_y + 3 < mapa_config. mapaSize_y then
      if (mapa[player_tile_y + 3][player_tile_x + 1] ~= "X") then
        player.jump = true
      end
    end    
  end  
    
  if player.jump then
    player.jumpTime = player.jumpTime + dt 
    player.pos_y = player.pos_y - ((player.jumpForce + 600) * dt) 
    player.jumpForce = player.jumpForce - (3 * dt)
    if player.jumpTime > 0.5 then
      player.jump = false 
      player.jumpTime = 0
    end
  end 
  
  if player_tile_y + 3 < mapa_config. mapaSize_y then
    if (mapa[player_tile_y + 3][player_tile_x + 4] == "X") or (mapa[player_tile_y + 2][player_tile_x + 1] == "A") or (mapa[player_tile_y + 2][player_tile_x + 1] == "A") then
      player.pos_y = player.pos_y + (gravity * dt)
    end
    if player_tile_y and player_tile_x == "A" then
      player.pos_y = player.pos_y - (gravity * dt)
      end
    if camera.pos_x < 0 then
    camera.pos_x = 0
  elseif camera.pos_x > mapa_config.mapaSize_x * tileSize - mapa_config.mapaDisplay_x * tileSize - 1 then
    camera.pos_x = mapa_config.mapaSize_x * tileSize - mapa_config.mapaDisplay_x * tileSize - 1
  end  
end
end
end